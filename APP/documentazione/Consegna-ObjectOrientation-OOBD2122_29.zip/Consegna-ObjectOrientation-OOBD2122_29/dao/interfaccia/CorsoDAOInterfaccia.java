package dao.interfaccia;

import dto.Corso;
import eccezioni.associazioni.AssociazioneFallitaException;
import eccezioni.create.CreateFallitoException;
import eccezioni.delete.DeleteFallitoException;
import eccezioni.retrieve.RetrieveFallitoException;
import eccezioni.update.UpdateFallitoException;
import java.util.LinkedList;

public interface CorsoDAOInterfaccia {
    
    public void createCorso(Corso corso) throws CreateFallitoException;
    
    public LinkedList<Corso> retrieveAllCorso() throws RetrieveFallitoException, AssociazioneFallitaException;
    
    public void updateCorso(Corso corso) throws UpdateFallitoException;
    
    public void deleteCorso(Corso corso) throws DeleteFallitoException;
    
}